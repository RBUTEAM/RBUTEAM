from jinja2 import Environment, FileSystemLoader
import argparse
import commands
parser = argparse.ArgumentParser()
parser.add_argument("-i", dest="filename", required=True,help="input file with two matrices")
args = parser.parse_args()
#print(args.filename)
def run_cmd(filename,commit_result_dict):
    
    check=0
    status, output = commands.getstatusoutput("grep -v \"^?\|cvs\" ./{}".format(filename))
    #print(output)
    revision=0
    revision_dict={}
    commit_info={}
    commit_list=[]
    BugId_flag=0 
    for line in output.splitlines():
        
        if not line.strip():
            commit_info={}
            check=1
        elif line.startswith('========'):
            if int(BugId_flag) == 0:
                commit_info["revision{}".format(revision)]=revision_dict
            else:
                revision=revision-1    
            commit_info["revisionCount"]=revision
            commit_list.append(commit_info)
            check=0
            revision=0
        else:
            if check == 1:
                if line.startswith('RCS file'):
                    rcs_file=line.split(': ')[1]
                    commit_info["RCS file"]=rcs_file
                elif line.startswith('Working file'):
                    working_file = line.split(': ')[1]
                    commit_info["Working file"]=working_file
                elif line.startswith('revision'):
                    revision_dict={}
                    revision_dict["id"]=line.split(' ')[1]
                    revision=revision+1
                
                elif line.startswith('-----------'):
                    if  int(revision) > 0:
                        if int(BugId_flag) == 0:
                            commit_info["revision{}".format(revision)]=revision_dict
                        else:
                            revision=revision-1
                            revision_dict={} 
                elif not revision == 0:
                    if line.startswith('date'):
                        revision_dict["date"]=line.split('date: ')[1].split(';')[0]
                        revision_dict["author"]=line.split('author: ')[1].split(';')[0]
                        revision_dict["state"]=line.split('state: ')[1].split(';')[0]
                        revision_dict["commitid"]=line.split('commitid: ')[1].split(';')[0] 
                        BugId_flag=1 
                    elif line.startswith('@BugId'):
                        revision_dict["BugId"]=line.split(':')[1].split(' ')[0]
                        revision_dict["Author"]=line.split(':')[2].split(' ')[0]
                        revision_dict["ModuleName"]=line.split(':')[3].split(' ')[0]
                        revision_dict["Reviewer"]=line.split(':')[4].split(' ')[0]
                        revision_dict["Comment"]=line.split(':')[5].split(' ')[0] 
                        BugId_flag=0
    dict_out={}
    dict_out["ReleaseID"]=filename.split('_')[0]
    dict_out["log"]=commit_list
    commit_result_list=[]
    for line in dict_out["log"]:
        count = 0
        for i in range(0,line["revisionCount"]):
            if line["revision{}".format(i+1)]["BugId"] in ('NA','-'):
                count=count+1
        if count > 0:
           commit_result_list.append(line)
    commit_result_dict[dict_out["ReleaseID"]]=commit_result_list
    return commit_result_dict
def main():
    commit_result_dict={}
    with open(args.filename) as f:
        for line in f:
            if line.strip().split(' ')[1] == "0":
                filename="{}_daily_commit.log".format(line.strip().split(' ')[0])
            else:
                filename="{}_daily_commit.log".format(line.strip().replace(" ","."))
            commit_result_dict=run_cmd(filename,commit_result_dict)
    #print commit_result_dict
    env = Environment(loader=FileSystemLoader('templates'))
    template = env.get_template('new_sample.html')
    output_from_parsed_template = template.render(result=commit_result_dict)
    #print output_from_parsed_template
    with open("my_new_file.html", "wb") as fh:
        fh.write(output_from_parsed_template)
main()
