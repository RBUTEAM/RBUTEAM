import os
def iscore(f, pattern):
    isfile = os.path.isfile
    return (pattern in f and not 'nsi_find_core.py' in f) and isfile(f)


default=os.getenv('HOME')+"/core_files"
pattern="core.!home!cavisson!work!"
print(default)
cores = [ f for f in map(lambda f: os.path.join(os.path.abspath(default), f), os.listdir(default)) if iscore(f, pattern)]
print(cores)
