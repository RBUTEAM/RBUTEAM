#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../../include/ns_string.h"
#include "script.h"

int init_script() {

	return index_html;
}

int pre_page_index_html(void) {
ns_start_transaction("hpd_page1_trans1");


   return NS_USE_CONFIGURED_THINK_TIME;
}

int check_page_index_html(void) {
ns_end_transaction("hpd_page1_trans1", 0);



	return login;
}

int pre_page_login(void) {
ns_start_transaction("hpd_page2_trans2");

   return NS_USE_CONFIGURED_THINK_TIME;
}

int check_page_login(void) {
ns_end_transaction("hpd_page2_trans2", 0);


	return reservation;
}

int pre_page_reservation(void) {
ns_start_transaction("hpd_page3_trans3");

   return NS_USE_CONFIGURED_THINK_TIME;
}

int check_page_reservation(void) {
ns_end_transaction("hpd_page3_trans3", 0);


	return findflight;
}

int pre_page_findflight(void) {
ns_start_transaction("hpd_page4_trans4");

   return NS_USE_CONFIGURED_THINK_TIME;
}

int check_page_findflight(void) {
ns_end_transaction("hpd_page4_trans4", 0);


	return findflight_2;
}

int pre_page_findflight_2(void) {
ns_start_transaction("hpd_page5_trans5");

   return NS_USE_CONFIGURED_THINK_TIME;
}

int check_page_findflight_2(void) {
ns_end_transaction("hpd_page5_trans5", 0);


	return findflight_3;
}

int pre_page_findflight_3(void) {
ns_start_transaction("hpd_page6_trans6");

   return NS_USE_CONFIGURED_THINK_TIME;
}

int check_page_findflight_3(void) {
ns_end_transaction("hpd_page6_trans6", 0);


	return welcome;
}

int pre_page_welcome(void) {
ns_start_transaction("hpd_page7_trans7");

   return NS_USE_CONFIGURED_THINK_TIME;
}

int check_page_welcome(void) {
ns_end_transaction("hpd_page7_trans7", 0);

	return -1;
}

void exit_script() {
	return;
}
