#!/usr/bin/env bash

# Include  libraries
source $NS_WDIR/lib/automation_util
source $NS_WDIR/lib/automation_config.dat 

# Bootstraps the automation test specific variables
function init() {
    CUR_DIR=$(pwd)

    RELEASE=$(cat $NS_WDIR/etc/version |grep VERSION| cut -d " "  -f2| cut -d . -f1,2,3)
    MAJOR=$(cat $NS_WDIR/etc/version | head -1 |cut -d "." -f4)
    MINOR=$(cat $NS_WDIR/etc/version | tail -1  | cut -d " " -f2)

    # Results directory to store the automation result.
    R_DIR="${CUR_DIR}/results/$RELEASE/${MINOR}"
     
      #Psql test checkup file
   >/tmp/pretest_check_stat

       
    # Create results workbench if not exists
    [ ! -d "${R_DIR}" ] && mkdir -p "${R_DIR}"

    # Temporary File
    TEMP_FILE=/tmp/ns_run.$$

    # Result File.
    CYCLENO=$(get_cycle_num)
    R_FILE="${R_DIR}/${testSuite}_${CYCLENO}.txt"
    XML_FILE="${R_DIR}/${testSuite}_${CYCLENO}.xml"

    export R_FILE
    export XML_FILE
    export TEMP_FILE
}


# Using bin/ts_run to start testsuite
function run(){
    testSuite="$1"            
    debug_opt="$2"            

    # Changing directory location to ns_wdir
    cd $NS_WDIR

    echo "Starting NSCore smoke automation suite using command bin/ts_run"
    echo "Running TestSuite = '$testSuite'"

    # running test in backend
    Project=$(project_name $testSuite)
    echo "Project name is=$Project"
    #bin/ts_run -n ${Project}/${testSuite} | tee $TEMP_FILE    
    
	suites=$(cat /home/automation/workbench/automation/nscore_parallel/smoke_4.1.11/testsuites/running_suites.conf |grep -v "#")
	pids=
	suite_count=0
	for suite in ${suites}
	do
		nohup ts_run -n $Project/$suite | tee $TEMP_FILE &> /tmp/$suite.log &
		suite_count=$((suite_count+1))
		echo "smoke suite${suite_count} is started, please check /tmp/$suite.log"
		sleep 15
		pids="$! $pids"
	done
	echo "Testsuites started successfully, Please wait till completion !!"
    for pid in $pids
	do
		wait $pid
	done
    echo "end time=`date`"
    #Check return code. If RC=2, automation timed out case. RC=0 Success
    RC=$?

    [ $RC -ne 0 ] && {
       echo "Possible test case failure. Check logs..."
    } || {
       echo "NSCore ${testSuite} automation suite has ended"
    }

    [ "X$debug_opt" == "X--debug" ] && {
       copy_logs
     }

    # Set currently finshed testsuite summary 
    set_test_summary_ex
    
    # Changing directory location back to automation_wdir
    cd - >/dev/null
}


# Cleans up temporary files
function clean_up(){
    echo "Cleaning up temporary files"
    rm -f ${TEMP_FILE}
}


# To copy TR's in current directory logs folder.
# Only when --debug option is passed while running the shell;
function copy_logs(){
    [ ! -d ${CUR_DIR} ] && mkdir -p ${CUR_DIR}/logs

    sleep 1
    
    for trNum in $(grep TestRun ${TEMP_FILE} |awk -F'=' '{print $2}')
    do
	if [ -d $NS_WDIR/logs/TR${trNum} ];then
	  debug_log "Debug: Copying test runs to ${CUR_DIR}/logs"
	  cp -r $NS_WDIR/logs/TR${trNum} ${CUR_DIR}/logs/
	  
          debug_log "Copied TR${trNum}"
	
        else
	  debug_log "TestRun not found"
	fi
    done
}


#  Returns count of testcases to run in current testsuite
function get_test_case_count() {
	suites=$(cat /home/automation/workbench/automation/nscore_parallel/smoke_4.1.11/testsuites/running_suites.conf |grep -v "#")
	total_count=0
	for suitename in $suites
	do
		testcases=$(cat testsuites/${suitename}.conf |grep -v "#" | cut -d ' ' -f2)
		count=0
		for testcase in ${testcases}
		do
			i=$(grep -ci "^SMOKE-" testcases/${testcase}/iteration.spec)
		    count=$(($count + $i))
		done
		total_count=$(($total_count + $count))
	done
	echo ${total_count}
}

# numbers of NSFail testcases
function update_test_status() {
    suites="$1"
	NSFail=0
	suite_count=1
	echo "#Test Information" > /tmp/last2
	for suitename in $suites
	do
    cycle_num=$(grep "Test Cycle Number" /tmp/${suitename}.log | egrep -o [0-9_]+)
	echo "tsr_no${suite_count}=${cycle_num}">>/tmp/last2
    NSFailCount=$(grep -c "NetstormFail" $NS_WDIR/logs/tsr/${cycle_num}/cycle_summary.report)
	NSFail=$((NSFail+NSFailCount))
    suite_count=$((suite_count+1))
    done
    TotalExecuted=$(get_test_case_count)
    tsr_no=${cycle_num}
    os_type=$(lsb_release -d|awk -F ' ' '{print $2" "$3}')
    load_avg=$(uptime | grep -ohe 'load average[s:][: ].*'| cut -d ':' -f2)
    cpu_avg=$(grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END {print usage "%"}')
    echo "NSFailCount=$NSFail" >>/tmp/last2
    echo "os=$os_type">>/tmp/last2
    echo "loadaverage=$load_avg">>/tmp/last2
    echo "cpu_utilation=$cpu_avg">>/tmp/last2
    echo "TotalExecuted=$TotalExecuted" >>/tmp/last2

}

function get_ns_fail_result(){
cycle_num="$1"
count=0
ns_fail_log="/tmp/ns_smoke_fail_log"
export NS_wdir="/home/cavisson/work"
test_suite_dir="$NS_wdir/logs/tsr/${cycle_num}"
NSFailsName1=($(cat ${test_suite_dir}/cycle_summary.report |grep "NetstormFail" |cut -d " " -f2))
NSFailsName2=($(cat ${test_suite_dir}/cycle_summary.report |grep "NetstormFail" |cut --complement -d " " -f2|cut -d "l" -f2))
>${ns_fail_log}
TEST_SUITE_ID=`cat /home/cavisson/etc/test_suite_run_id`
   for NSFDir in ${NSFailsName1[@]}
   do
       fail=$(echo $NSFDir | cut -d ">" -f1|head ${nslog} | sed -e 's/</_/;s/>//;s/-/_/')
       logErr=$(tail ${test_suite_dir}/$((TEST_SUITE_ID-1))/logs/$fail/test_run.report)
       echo "Report|$NSFDir|${NSFailsName2[$count]}|$logErr">>${ns_fail_log}
       echo " " >>${ns_fail_log}
       echo "Report|$NSFDir|${NSFailsName2[$count]}|$logErr"
       count=$((count+1))
    done

}

# Execution begins from here
function main() {
    # Bootstraps the automation test specific variables
    echo "Initializing test environment "
    init

    # Display testcase count
    echo "Total Cases to test in ${testSuite} suite = $(get_test_case_count)"

    #This function creates the header for result file.
    set_results_header_ex

    #Call to run  to start automation
    run "${testSuite}" "${debug_opt}"

    # TODO
    # Variable to use update_test_status module 
    # To get total and nsfail testcase count
    #TSR_DIR=$(grep "Test Cycle Number" ${TEMP_FILE} | egrep -o [0-9_]+)
    
    # Cleans up tmporary files
    clean_up

    # Check cycle summary report file and append total test run executed
    # check for netstorm failed cases and update the count
    update_test_status "${suites}"
    
    get_ns_fail_result "${TSR_DIR}"
    # Module called to upload testresults to sqlite database
    #echo "Uploading results to remote database"
     echo "echo "As it is debug test so it will not going to upload result in a database""
    #${DB_UPLOAD} -r ${RELEASE} -v ${MINOR} -f ${R_FILE}
    exit 0
}


# Permit only 'automation' user to run test
#[ "X${USER}" != "Xnetstorm" ] && echo "ERROR: You must log in with 'netstorm' user" && exit -1
# Changed by biswajit as test shall be started with cavisson user as per 4.1.11 release

[ "X${USER}" != "Xcavisson" ] && echo "ERROR: You must log in with 'cavisson' user current user = $USER" && exit -1


# Store all command line arguments to shell
testSuite="${1}"
debug_opt="${2}"


# Call to main function
main
