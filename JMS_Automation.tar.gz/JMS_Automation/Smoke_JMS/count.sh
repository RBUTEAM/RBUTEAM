suites=$1
function get_test_case_count() {
	echo $suites
	#suites=$(cat /home/automation/workbench/automation/nscore_parallel/smoke_4.1.11/testsuites/running_suites.conf |grep -v "#")
    total_count=0
    for suitename in $suites
	do
		testcases=$(cat testsuites/${suitename}.conf |grep -v "#" | cut -d ' ' -f2)
		count=0
		for testcase in ${testcases}
		do
			i=$(grep -ci "^SMOKE-" testcases/${testcase}/iteration.spec)
			count=$(($count + $i))
		done
	    total_count=$(($total_count + $count))
     done
	 echo ${total_count}
 }
 get_test_case_count

