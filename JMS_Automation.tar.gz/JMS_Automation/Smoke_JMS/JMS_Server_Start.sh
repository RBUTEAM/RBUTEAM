#!/bin/bash

#start IBM server
#sshpass -p 'onloopns' ssh -p 79 root@10.10.30.55 "cd /home/cavisson/docker-apps/ibmq/ && docker-compose up -d"
sshpass -p 'onloopns' ssh root@10.10.30.55 "cd /home/cavisson/docker-apps/ibmq/ && docker-compose up -d"
sleep 2s

#start Kafka server
#sshpass -p 'onloopns' ssh -p 79 root@10.10.30.55 "cd /home/cavisson/docker-apps/kafka/ && docker-compose up -d"
sshpass -p 'onloopns' ssh root@10.10.30.55 "cd /home/cavisson/docker-apps/kafka/ && docker-compose up -d"
sleep 2s

#start Tibco server
#sshpass -p 'onloopns' ssh -p 79 root@10.10.30.55 "ps -e | grep tib"
sshpass -p 'onloopns' ssh root@10.10.30.55 "ps -e | grep tib"
value=$(echo $?)
if [[ "$value" -eq 0 ]];then
echo Tibco server already start.
else
#sshpass -p 'onloopns' ssh -p 79 root@10.10.30.55 "cd /opt/tibco/ems/8.5/ && sh trigger.sh"
sshpass -p 'onloopns' ssh root@10.10.30.55 "cd /opt/tibco/ems/8.5/ && sh trigger.sh"
sleep 2s
echo Tibco server is started.
fi

#start Tibco_ssl server
sshpass -p 'Netst0rm' ssh root@10.10.30.20 "ps -e | grep tib"
value=$(echo $?)
if [[ "$value" -eq 0 ]];then
echo Tibco_ssl server already start.
else
sshpass -p 'Netst0rm' ssh root@10.10.30.20 "cd /opt/tibco/ems/8.5/ && sh trigger.sh"
sleep 2s
echo Tibco_ssl server is started.
fi

#Start Kafka_ssl server
sshpass -p 'onloopns' ssh root@10.10.30.18 "cd /home/cavisson/work_3/Mukesh/kafka/kafka_2.11-1.0.0/ && sh Restart_Server.sh"

##start Zookeeper server
#sshpass -p 'onloopns' ssh root@10.10.30.18 "netstat -natp | grep -w "2181" | grep -w "LISTEN""
#value=$(echo $?)
#if [[ "$value" -eq 0 ]];then
#echo Zookeeper server already start.
#else
#sshpass -p 'onloopns' ssh root@10.10.30.18 "cd /home/cavisson/work_3/Mukesh/kafka/kafka_2.11-1.0.0/ && sh zookeeper.sh"
#sleep 2s
#echo Zookeeper server is started.
#fi
#
##start Kafka_ssl server
#sshpass -p 'onloopns' ssh root@10.10.30.18 "netstat -natp | grep -w "9092" | grep -w "LISTEN""
#value=$(echo $?)
#if [[ "$value" -eq 0 ]];then
#echo Kafka_ssl server already start.
#else
#sshpass -p 'onloopns' ssh root@10.10.30.18 "cd /home/cavisson/work_3/Mukesh/kafka/kafka_2.11-1.0.0/ && sh kafka.sh"
#sleep 2s
#echo Kafka_ssl server start successfully.
#fi
#
exit 0
