#!/bin/bash
#Below shell is to stop stucked test on automation automatically.
#Author :- Anup Kumar (17 Nov 2019)

rm /tmp/tr_killed.log
base_time=001500
echo "Process id of kill.sh is $$" >> /tmp/tr_killed.log
while true
do
	TR_NUM=$(nsu_show_netstorm -l | tail -1 | awk '{print $1}')
	HH=$(nsu_show_netstorm -l | tail -1 | awk '{print $5}' | awk -F ':' '{print $1}')
	MM=$(nsu_show_netstorm -l | tail -1 | awk '{print $5}' | awk -F ':' '{print $2}')
	SS=$(nsu_show_netstorm -l | tail -1 | awk '{print $5}' | awk -F ':' '{print $3}')
	elapsed_time=$HH$MM$SS
	tmp=$( expr $base_time - $elapsed_time )
	sleep 5
	echo "TR$TR_NUM --> Remaining time $tmp" >> /tmp/tr_killed.log
	if [ $tmp -gt 0 ]
	then
		continue
	else
		new_TR_NUM=$(nsu_show_netstorm -l | tail -1 | awk '{print $1}')
		if [ $TR_NUM -eq $new_TR_NUM ]
		then
			echo "Going to stop running test --> TR$TR_NUM" >>/tmp/tr_killed.log
			nsu_stop_test -f $TR_NUM
			var=$?
			if [ $var -eq 0 ]
			then
				echo "TR$TR_NUM is killed due to test stuck." >> /tmp/tr_killed.log
			fi
		fi
	fi
done
