import os
from datetime import date, timedelta
import argparse
import commands
parser = argparse.ArgumentParser()
parser.add_argument("-i", dest="filename", required=True,help="input the Branch details file Name")
args = parser.parse_args()
def get_cvs_log(release,branch):
    yesterday = date.today() - timedelta(1)
    yesterday_date=yesterday.strftime('%y-%m-%d')
    #print(branch)
    if os.path.isdir("/home/build/work_{}".format(release.replace(".",""))):
        if branch == "0":
            cmd="cvs log -N -S -rBRANCH_{} -d \">{}\" &>/tmp/{}_daily_commit.log".format(release.replace(".","_"),yesterday_date,release)
        else:
            cmd="cvs log -N -S -rBRANCH_{}_{} -d \">{}\" &>/tmp/{}.{}_daily_commit.log".format(release.replace(".","_"),branch,yesterday_date,release,branch)
        os.chdir("/home/build/work_{}".format(release.replace(".",""))) 
    else:
        cmd="cvs log -N -S -d \">{}\" &>/tmp/{}_daily_commit.log".format(yesterday_date,release)
        os.chdir("/home/build/NSCVS")
    print(cmd)
    #status , output=commands.getstatusoutput(cmd)

def main():
    with open(args.filename) as f:
        for line in f:
            release=line.strip().split(" ")[0]
            branch=line.strip().split(" ")[1]
            get_cvs_log(release,branch)
main()
