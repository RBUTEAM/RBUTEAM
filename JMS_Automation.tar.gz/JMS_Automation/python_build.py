import paramiko
hostname = '10.10.30.96'    
port = 22
username = 'cavisson'
password = 'cavisson'
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(hostname, port,username, password, look_for_keys=False , compress=True)
command = '/bin/bash /home/cavisson/work/upgrade/upgrade_build.sh'
(stdin, stdout, stderr) = ssh.exec_command('bash -x /home/cavisson/work/upgrade/upgrade_build.sh')
for line in stdout.readlines():
    print line
for line in stderr.readlines():
    print line
s.close()
print("comeplted")
print(__name__)
