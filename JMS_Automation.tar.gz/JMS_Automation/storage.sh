# !/bin/bash
fr_space=$(df -h --total |  awk ' {print $5} ' | tail -n 1 | cut -c 1-2)
echo 'Free Space is: '$fr_space
if [ $fr_space -gt 95 ]
then
	echo 'Success'
else
	echo 'Test will continue'
fi
